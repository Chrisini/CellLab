package uk.ac.soton.ecs.ceb1n19.ch3;

//import java.io.File; // for exporting image
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openimaj.image.DisplayUtilities;
import org.openimaj.image.ImageUtilities;
import org.openimaj.image.MBFImage;
import org.openimaj.image.colour.ColourSpace;
import org.openimaj.image.pixel.PixelSet;
import org.openimaj.image.processor.PixelProcessor;
import org.openimaj.image.segmentation.FelzenszwalbHuttenlocherSegmenter;
import org.openimaj.image.segmentation.SegmentationUtilities;
import org.openimaj.ml.clustering.FloatCentroidsResult;
import org.openimaj.ml.clustering.assignment.HardAssigner;
import org.openimaj.ml.clustering.kmeans.FloatKMeans;

import cern.colt.Arrays;

/**
 * @author Christina Bornberg 31456936
 * 
 * @done true
 * 
 * @task 3.1.1. Exercise 1: The PixelProcessor 3.1.2. Exercise 2: A real
 *       segmentation algorithm
 * 
 * @resources The OpenIMAJ Tutorial
 */
public class ProcessPixels {

	/**
	 * Using a pixel processor
	 * 
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	private void pixel_processor() throws MalformedURLException, IOException {

		// Loading image vie URL
		MBFImage image = new MBFImage();
		image = ImageUtilities.readMBF(new URL(
				"https://thumbor.forbes.com/thumbor/960x0/https%3A%2F%2Fblogs-images.forbes.com%2Fjamiecartereurope%2Ffiles%2F2019%2F02%2F1-2-1200x675.jpg"));

		// Colour space transformation
		image = ColourSpace.convert(image, ColourSpace.CIE_Lab);

		// Construct K-Means algorithm
		FloatKMeans cluster = FloatKMeans.createExact(2);

		// Flatten and group pixels
		float[][] image_data = image.getPixelVectorNative(new float[image.getWidth() * image.getHeight()][3]);
		FloatCentroidsResult result = cluster.cluster(image_data);

		// Print centroid: (L, a, b) - from CIE_Lab colourspace
		final float[][] centroids = result.centroids;
		for (float[] fs : centroids) {
			System.out.println(Arrays.toString(fs));
		}

		// Hard assigner for the image
		final HardAssigner<float[], ?, ?> assigner = result.defaultHardAssigner();

		/*
		 * The Pixel processor automatically loops through the image. By using
		 * System.out.println(Arrays.toString(pixel)); each pixel with the dimensions L,
		 * a, b are printed Example for one line: [41.899956, 4.2016478, 9.808258]
		 * 
		 * The pixel processor addresses each pixel, the developer doesn't need to care
		 * about the position of the pixel. The only problem is the cast. Arrays can't
		 * be copied/accessed without a loop.
		 */
		image.processInplace(new PixelProcessor<Float[]>() {
			public Float[] processPixel(Float[] pixel) {
				float[] fp = new float[3];
				for (int lab = 0; lab < 3; lab++) {
					fp[lab] = pixel[lab];
				}
				final int centroid = assigner.assign(fp);
				System.out.println(Arrays.toString(centroids[centroid]));
				for (int lab = 0; lab < 3; lab++) {
					pixel[lab] = centroids[centroid][lab];
				}
				System.out.println(Arrays.toString(pixel));
				return pixel;
			}
		});

		image = ColourSpace.convert(image, ColourSpace.RGB);
		DisplayUtilities.display(image);
	}

	/**
	 * Felzenszwalb Huttenlocher Segmenter
	 * 
	 * Used website:
	 * https://www.programcreek.com/java-api-examples/?class=org.openimaj.image.segmentation.FelzenszwalbHuttenlocherSegmenter&method=segment
	 * 
	 * With the segmenter, multiple objects were segmented. For binary
	 * classification, a HardAssigner or similar would need to be used again.
	 * 
	 * @throws IOException
	 * @throws MalformedURLException
	 */
	private void seg_algorithm() throws MalformedURLException, IOException {

		MBFImage image = new MBFImage();
		image = ImageUtilities.readMBF(new URL(
				"https://thumbor.forbes.com/thumbor/960x0/https%3A%2F%2Fblogs-images.forbes.com%2Fjamiecartereurope%2Ffiles%2F2019%2F02%2F1-2-1200x675.jpg"));

		// create new segmenter
		FelzenszwalbHuttenlocherSegmenter<MBFImage> fhs = new FelzenszwalbHuttenlocherSegmenter<MBFImage>();

		// Put segments into a list
		final List<? extends PixelSet> segments = fhs.segment(image);

		// Render segments
		image = SegmentationUtilities.renderSegments(image.getWidth(), image.getHeight(), segments);

		// Export image as jpg file
//		final File path = new File("C:\\Users\\Prinzessin\\Pictures");
//		ImageUtilities.write(image, new File(path, "chrisy8.jpg"));

		DisplayUtilities.display(image);
	}

	public static void main(String[] args) throws MalformedURLException, IOException {
		ProcessPixels pix = new ProcessPixels();
		pix.pixel_processor();

		ProcessPixels seg = new ProcessPixels();
		seg.seg_algorithm();
	}
}
